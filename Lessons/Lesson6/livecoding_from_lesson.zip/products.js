const products = [
  {
    id: 1,
    name: 'iPhone',
    price: 2000,
  },
  {
    id: 2,
    name: 'Samsung Galaxy S25',
    price: 1800,
  },
  {
    id: 3,
    name: 'Huawei',
    price: 1500,
  },
  {
    id: 4,
    name: 'Redmi',
    price: 1000,
  },
  {
    id: 5,
    name: 'Nokia 3310',
    price: 500,
  },
];